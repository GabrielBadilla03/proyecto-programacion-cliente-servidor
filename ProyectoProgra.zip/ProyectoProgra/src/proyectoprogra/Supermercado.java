/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprogra;

/**
 *
 * @author 11alp
 */
class Supermercado extends Usuario {
    public void iniciarSesion() {
        // Implementación
    }

    public void registrarVenta() {
        // Implementación
    }

    public Producto obtenerInfoProducto(int id) {
        // Implementación
        return null;
    }

    public Cajero asignarCajero(Venta venta) {
        // Implementación
        return null;
    }
    
}
