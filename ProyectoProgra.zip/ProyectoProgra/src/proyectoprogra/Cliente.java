/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprogra;

/**
 *
 * @author 11alp
 */
class Cliente extends Usuario {
    private String comprasAnteriores = " ";

    // Métodos adicionales de la clase Cliente
    public void realizarCompra() {
        // Implementación
    }

    public void consultarInventario() {
        // Implementación
    }

    public void verHistorialCompra() {
        // Implementación
    }

    public void metodoPago() {
        // Implementación
    }

    public void verDescuentoProducto(Producto producto) {
        // Implementación
    }

    public void aplicarDescuento() {
        // Implementación
    }
}
