/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprogra;

/**
 *
 * @author 11alp
 */
    class Producto implements Producto {
    private int id;
    private String nombre;
    private double precio;

    // Resto de atributos y métodos específicos de Producto

    @Override
    public int getID() {
        return id;
    }

    @Override
    public void setID(int ID) {
        this.id = ID;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public double getPrecio() {
        return precio;
    }

    @Override
    public void setPrecio(double precio) {
        this.precio = precio;
    }

}
